Links
=====

   `LibSerial-1.0.0rc1
   <https://github.com/crayzeewulf/libserial>`_

   `Documentation
   <http://libserial.readthedocs.io/en/latest/index.html>`_
