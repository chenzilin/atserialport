Download
========

The latest version of LibSerial is 1.0.0rc1. You can find the source code
for LibSerial-1.0.0rc1 `here <https://github.com/crayzeewulf/libserial>`_. 
Older versions of LibSerial may also be found at the above site.
