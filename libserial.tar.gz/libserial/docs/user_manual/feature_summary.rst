Feature Summary 
===============

* Simplified serial port programming in C++ under POSIX operating systems.
* Support for USB-serial converters.
* Access serial ports from scripting languages such as PHP, Python, Perl, 
  Ruby, and Java.
