.. LibSerial documentation master file, created by
   sphinx-quickstart on Sun Sep 17 10:46:50 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to LibSerial's documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   feature_summary
   description
   download
   install
   tutorial
   api_documentation
   design_documentation
   links

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
